from __future__ import print_function

# import Generator
import sys
sys.path.insert(1, '/content/digan/src/training')
sys.path.insert(1, '/content/digan/src/')
import dnnlib
from networks import Generator
from training_loop import training_loop

import hydra
from hydra.experimental import compose, initialize
import tensorflow as tf
import tensorflow_hub as hub
import matplotlib.pyplot as plt


# initialize(config_path="../digan/configs", job_name="INR-GAN training")
# hydra_cfg = compose(config_name=None)
# hydra_cfg = OmegaConf.load('../digan/configs/digan.yml')

# import vivit
sys.path.insert(1, '/content/ViViT-pytorch')
from vivit import ViViT

import apex
import cv2
import torch
from mmaction.apis import init_recognizer, inference_recognizer
from mmcv import Config
from mmcv.parallel import collate, scatter
from mmaction.models import build_model
from mmcv.runner.fp16_utils import wrap_fp16_model
from mmcv.runner import get_dist_info, init_dist, load_checkpoint

import argparse
import os
import math
import gc
import sys
import xlwt
import random
import numpy as np
# from advertorch.attacks import LinfBasicIterativeAttack
# from sklearn.externals import joblib
import joblib
# from utils import load_data
import pickle
import torch
import torchvision
import torch.nn.functional as F
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
from torch.nn.functional import mse_loss
import torch.optim as optim
import torch.utils.data
from torch.optim.lr_scheduler import StepLR
import torchvision.datasets as dset
import torchvision.transforms as transforms
import torchvision.utils as vutils
import torch.utils.data.sampler as sp
from net import Net_s, Net_m, Net_l
from vgg import VGG
from resnet import ResNet50, ResNet18, ResNet34
cudnn.benchmark = True
workbook = xlwt.Workbook(encoding = 'utf-8')
worksheet = workbook.add_sheet('imitation_network_sig')
nz = 128

class Logger(object):
    def __init__(self, filename='default.log', stream=sys.stdout):
	    self.terminal = stream
	    self.log = open(filename, 'a')

    def write(self, message):
	    self.terminal.write(message)
	    self.log.write(message)

    def flush(self):
	    pass

sys.stdout = Logger('imitation_network_model.log', sys.stdout)

parser = argparse.ArgumentParser()
parser.add_argument('--workers', type=int, help='number of data loading workers', default=2)
parser.add_argument('--batchSize', type=int, default=4, help='input batch size')
parser.add_argument('--dataset', type=str, default='azure')
parser.add_argument('--niter', type=int, default=2000, help='number of epochs to train for')
parser.add_argument('--lr', type=float, default=1e-4, help='learning rate, default=0.0002')
parser.add_argument('--beta1', type=float, default=0.5, help='beta1 for adam. default=0.5')
parser.add_argument('--cuda', default=True, action='store_true', help='enables cuda')
parser.add_argument('--manualSeed', type=int, help='manual seed')
parser.add_argument('--alpha', type=float, default=0.2, help='alpha')
parser.add_argument('--beta', type=float, default=0.1, help='alpha')
parser.add_argument('--G_type', type=int, default=1, help='iteration limitation')
parser.add_argument('--save_folder', type=str, default='/content/saved_models', help='alpha')
parser.add_argument('--save_generator_folder', type=str, default='/content/saved_generator_models', help='alpha')
parser.add_argument('--start_epoch', type = int, default=0, help = 'last epoch number')

opt = parser.parse_args()

if torch.cuda.is_available() and not opt.cuda:
    print("WARNING: You have a CUDA device, so you should probably run with --cuda")

# if opt.dataset == 'azure':
#     testset = torchvision.datasets.MNIST(root='dataset/', train=False,
#                                         download=True,
#                                         transform=transforms.Compose([
#                                                 # transforms.Pad(2, padding_mode="symmetric"),
#                                                 transforms.ToTensor(),
#                                                 # transforms.RandomCrop(32, 4),
#                                                 # normalize,
#                                         ]))
#     netD = Net_l().cuda()
#     netD = nn.DataParallel(netD)

#     clf = joblib.load('pretrained/sklearn_mnist_model.pkl')

#     adversary_ghost = LinfBasicIterativeAttack(
#         netD, loss_fn=nn.CrossEntropyLoss(reduction="sum"), eps=0.25,
#         nb_iter=100, eps_iter=0.01, clip_min=0.0, clip_max=1.0,
#         targeted=False)
#     nc=1

device = torch.device("cuda:0" if opt.cuda else "cpu")
# custom weights initialization called on netG and netD
def weights_init(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        m.weight.data.normal_(0.0, 0.02)
    elif classname.find('BatchNorm') != -1:
        m.weight.data.normal_(1.0, 0.02)
        m.bias.data.fill_(0)

def cal_azure(model, data):
    data = data.view(data.size(0), 784).cpu().numpy()
    output = model.predict(data)
    output = torch.from_numpy(output).cuda().long()
    return output

def cal_azure_proba(model, data):
    data = data.view(data.size(0), 784).cpu().numpy()
    output = model.predict_proba(data)
    output = torch.from_numpy(output).cuda().float()
    return output


class Loss_max(nn.Module):
    def __init__(self):
        super(Loss_max, self).__init__()
        return

    def forward(self, pred, truth):
        criterion = nn.CrossEntropyLoss()
        pred_prob = F.softmax(pred, dim=1)
        loss = criterion(pred, truth)
        # loss = criterion(pred, truth)
        final_loss = torch.exp(loss * -1)
        return final_loss

def load_ckp(checkpoint_fpath, model, optimizer):
    checkpoint = torch.load(checkpoint_fpath)
    model.load_state_dict(checkpoint['state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer'])
    return model, optimizer



######## declare the start epoch #########
start_epoch = start_epoch - start_epoch%10


######## vivit ########
# netD = Net_l().cuda()    #vivit
# netD = nn.DataParallel(netD)
netD = ViViT(128, 16, 600, 50).cuda()

######## MovieNet ########
with open('/content/kinetics_600_labels.txt', 'r') as f:
  label_text = f.read()
  label_text = [i for i in label_text.split('\n')][:-1]
  f.close()

hub_url = "https://tfhub.dev/tensorflow/movinet/a2/base/kinetics-600/classification/3"

encoder = hub.KerasLayer(hub_url, trainable=True)

inputs = tf.keras.layers.Input(
    shape=[None, None, None, 3],
    dtype=tf.float32,
    name='image')

# [batch_size, 600]
outputs = encoder(dict(image=inputs))
model = tf.keras.Model(inputs, outputs, name='movinet')

# out = inference_recognizer(model, 'demo/demo.mp4', 'demo/label_map_k400.txt')
# print(f"Out is \n\n\n {out}")
# print(f"Top is {out[0][0]}")
# print(f"label is {label_text.index(out[0][0])}")


########## DiGAN ###########
netG = training_loop()
for p in netG.parameters():
  p.requires_grad = True
criterion = nn.CrossEntropyLoss()
criterion_max = Loss_max()


# setup optimizer
steps = 10
optimizerD = optim.Adam(netD.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999))
optimizerG = optim.Adam(netG.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999))
schedulerD = torch.optim.lr_scheduler.CosineAnnealingLR(optimizerD,steps)
schedulerG = torch.optim.lr_scheduler.CosineAnnealingLR(optimizerG,steps)
# load previously saved checkpoints
netD, optimizerD = load_ckp('/content/saved_models/netD_epoch_'+str(start_epoch)+'.pth', netD, optimizerD)
netG, optimizerG = load_ckp('/content/saved_generator_models/netG_epoch_'+str(start_epoch)+'.pth', netG, optimizerG)

batch_num = 100
best_accuracy = np.inf
for epoch in range(start_epoch+1 , opt.niter):
    if epoch % steps:
        schedulerD.step()
        schedulerG.step()
    netD.train()
    avg_loss = 0
    for ii in range(batch_num):
        netD.zero_grad()

        ############################
        # (1) Update D network:
        ###########################

        z = torch.randn(opt.batchSize, 512).cuda()
        labels = torch.randint(0, 600, (opt.batchSize,))
        temp_labels = torch.zeros(opt.batchSize, 600)
        for i in range(temp_labels.shape[0]):
          temp_labels[i][labels[i]] = 1
        c = temp_labels.cuda()

        # forward pass through netG
        data, _ = netG(z, c , timesteps = 50)
        data = data.reshape(opt.batchSize, -1, 3, 128, 128)
        set_label = c

        index = torch.randperm(set_label.size()[0])
        data = data[index]
        set_label = set_label[index]
        set_label = torch.argmax(set_label, dim = 1)

        data = (data - data.min())/(data.max()-data.min())


        # obtain the output label of T
        with torch.no_grad():
          movienet_label_list = []
          for num_video in range(data.shape[0]):
            # print(f"working on video {num_video}")
            video = data[num_video].cpu().permute(0,2,3,1) # 50, 3, 128, 128
            # print(np.mean(np.array(video),axis = 2), np.std(np.array(video), axis = 2))
            # to .mp4 file
            # if(not os.path.isfile(f'/content/buffer/demo.mp4')):
            #   print(f"Video file does not exist")
            # if ii%100 == 0:
            #   video_path = '/content/buffer/demo'+str(epoch)+'.mp4'
            #   # # print(f"video path is {video_path}")
            #   torchvision.io.write_video(video_path, video*255, 5)
            # # print(f"Successfully written video")
            v_shape = np.shape(np.array(video))
            input_video = tf.reshape(np.array(video), [1, v_shape[0], v_shape[1], v_shape[2], v_shape[3]])
            example_output = model(input_video)
            output_label_index = tf.argmax(example_output, -1)[0].numpy()
            # print(output_label_index)
            temp = torch.zeros(1, dtype = torch.int32)
            temp[0] = output_label_index
            movienet_label_list.append(temp)
          label = torch.stack(movienet_label_list).long()
          label = label.reshape(-1)
          label = label.to(device)

          # _, label = torch.max(outputs.data, 1)
          # outputs = F.softmax(outputs, dim=1)
      # _, label = torch.max(outputs.data, 1)
        # print(label)

        output = netD(data.detach())
        prob = F.softmax(output, dim=1)
        # print(torch.sum(outputs) / 500.)
        # errD_prob = mse_loss(prob, outputs, reduction='mean')      # we have only label from the oracle.
        errD_fake = criterion(output, label) # + errD_prob * opt.beta
        D_G_z1 = errD_fake.mean().item()
        errD_fake.backward()

        errD = errD_fake
        optimizerD.step()

        del output, errD_fake

        ############################
        # (2) Update G network:
        ###########################
        netG.zero_grad()
        output = netD(data)
        loss_imitate = criterion_max(pred=output, truth=label)  # remove mseloss which requires 
        loss_diversity = criterion(output, set_label.long())
        errG = opt.alpha * loss_diversity + loss_imitate
        if loss_diversity.item() <= 0.1:
            opt.alpha = loss_diversity.item()
        errG.backward()
        # print(p.grad.norm(2) for p in netG.parameters())
        D_G_z2 = errG.mean().item()
        optimizerG.step()

        if (ii % 20) == 0:
            print('[%d/%d][%d/%d] loss D: %.4f G: %.4f D(G(z)): %.4f / %.4f loss_imitate: %.4f loss_diversity: %.4f'
                % (epoch, opt.niter, ii, batch_num,
                    errD.item(), errG.item(), D_G_z1, D_G_z2, loss_imitate.item(), loss_diversity.item()))
        
        avg_loss += (errD.item() - avg_loss) / (ii+1)
    print(f"Epoch : {epoch}, average D loss = {avg_loss}")
    if avg_loss < best_accuracy:
        best_accuracy = avg_loss
        print('This is the best model')
    if epoch%10 == 0:
        checkpoint_netD = {
            'epoch': epoch,
            'state_dict': netD.state_dict(),
            'optimizer': optimizerD.state_dict()
        }
        checkpoint_netG = {
            'epoch': epoch,
            'state_dict': netG.state_dict(),
            'optimizer': optimizerG.state_dict()
        }
        torch.save(checkpoint_netD,
                  opt.save_folder + '/netD_epoch_%d.pth' % (epoch))
        torch.save(checkpoint_netG,
                  opt.save_generator_folder + '/netG_epoch_%d.pth' % (epoch))

    ################################################
    # estimate the attack success rate of trained D:
    ################################################
    # correct_ghost = 0.0
    # total = 0.0
    # netD.eval()
    # for data in testloader:
    #     inputs, labels = data
    #     inputs = inputs.cuda()
    #     labels = labels.cuda()

    #     adv_inputs_ghost = adversary_ghost.perturb(inputs, labels)
    #     with torch.no_grad():
    #         # outputs = original_net(adv_inputs_ghost)
    #         if opt.dataset == 'azure':
    #             predicted = cal_azure(clf, adv_inputs_ghost)
    #         else:
    #             outputs = original_net(adv_inputs_ghost)
    #             _, predicted = torch.max(outputs.data, 1)
    #         # _, predicted = torch.max(outputs.data, 1)

    #         total += labels.size(0)
    #         correct_ghost += (predicted == labels).sum()
    # print('Attack success rate: %.2f %%' %
    #         (100 - 100. * correct_ghost.float() / total))
    # if best_att < (total - correct_ghost):
    #     torch.save(netD.state_dict(),
    #                 opt.save_folder + '/netD_epoch_%d.pth' % (epoch))
    #     torch.save(netG.state_dict(),
    #                 opt.save_folder + '/netG_epoch_%d.pth' % (epoch))
    #     best_att = (total - correct_ghost)
    #     print('This is the best model')
    # worksheet.write(epoch, 0, (correct_ghost.float() / total).item())
    # del inputs, labels, adv_inputs_ghost
    # torch.cuda.empty_cache()
    # gc.collect()

    ################################################
    # evaluate the accuracy of trained D:
    ################################################
    # with torch.no_grad():
    #     correct_netD = 0.0
    #     total = 0.0
    #     netD.eval()
    #     for data in testloader:
    #         inputs, labels = data
    #         inputs = inputs.cuda()
    #         labels = labels.cuda()
    #         outputs = netD(inputs)
    #         _, predicted = torch.max(outputs.data, 1)
    #         total += labels.size(0)
    #         correct_netD += (predicted == labels).sum()
    #     print('Accuracy of the network on netD: %.2f %%' %
    #             (100. * correct_netD.float() / total))
    #     if best_accuracy < correct_netD:
    #         torch.save(netD.state_dict(),
    #                    opt.save_folder + '/netD_epoch_%d.pth' % (epoch))
    #         torch.save(netG.state_dict(),
    #                    opt.save_folder + '/netG_epoch_%d.pth' % (epoch))
    #         best_accuracy = correct_netD
    #         print('This is the best model')
    # worksheet.write(epoch, 1, (correct_netD.float() / total).item())
# workbook.save('imitation_network_saved_azure.xls')

