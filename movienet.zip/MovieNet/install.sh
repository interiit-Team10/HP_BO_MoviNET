#!/bin/bash
pip install ffmpeg
# pip install apex
pip install mmaction2
pip install mmcv